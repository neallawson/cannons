import './style.css';
import { GameState } from './game/GameState';
import { Renderer } from './game/Renderer';
import { GameLoop } from './game/GameLoop';
import { PhysicsEngine } from './game/PhysicsEngine';
import { NetworkManager } from './game/NetworkManager';
import { InputManager } from './game/InputManager';
import { AIOpponent } from './game/AIOpponent';
import type { Player, GameStateData } from './game/types';

const app = document.querySelector<HTMLDivElement>('#app')!;
app.innerHTML = `
  <canvas id="gameCanvas"></canvas>
  
  <div id="game-ui-container">
      <div id="hud-panel">
        <div id="game-info">
            <div id="game-count" class="hud-row">Game: 1</div>
            <div id="turn-display" class="hud-row">Turn: -</div>
        </div>
        <div id="score-board"></div>
        
        <div id="mp-label" style="text-align: center; font-size: 1.2rem; margin-top: 10px; color: #ddd; border-top: 1px solid #555; padding-top: 5px; cursor: pointer;">▶ 2-Player Mode</div>
        <div id="mp-controls" style="border-top: none; margin-top: 5px; padding-top: 0; display: none; flex-direction: column;">
            <div style="display: flex; flex-direction: row; gap: 10px; width: 100%;">
                <a id="hostBtn" class="btn-link" style="text-align:center; flex: 1;">Host Game</a>
                <a id="joinBtn" class="btn-link" style="text-align:center; flex: 1;">Join Game</a>
            </div>
            <div id="status" style="font-size: 1.8rem; color: #ccc; margin-top: 5px; text-align: center;"></div>
        </div>
      </div>

      <div id="ui-layer" style="position: absolute; bottom: 20px; left: 20px; color: white; font-family: sans-serif;">
        <label>Power: <input type="range" id="powerSlider" min="10" max="100" value="50"></label>
        <span id="powerValue">50</span>
      </div>
      <div id="window-size" style="position: absolute; top: 10px; right: 10px; color: lime; font-family: monospace; font-size: 16px; background: rgba(0,0,0,0.5); padding: 5px; pointer-events: none;"></div>
  </div>
`;

function log(msg: string) {
  console.log(msg);
}

const canvas = document.querySelector<HTMLCanvasElement>('#gameCanvas')!;
// Fixed Logical Resolution
const LOGICAL_WIDTH = 2488;
const LOGICAL_HEIGHT = 1332;

// Defer initialization until we have a seed
let gameState: GameState;
let renderer: Renderer;
let physicsEngine: PhysicsEngine;
let loop: GameLoop;

let isMultiplayer = false;
let myPlayerId = 'p1';

function updateHUD(state: GameStateData) {
  // Game Count
  const totalWins = state.players.reduce((sum: number, p: Player) => sum + p.wins, 0);
  document.getElementById('game-count')!.innerText = `Game: ${totalWins + 1}`;

  // Turn
  const currentPlayer = state.players.find(p => p.id === state.currentTurnPlayerId);
  if (currentPlayer) {
    const turnEl = document.getElementById('turn-display')!;
    turnEl.innerHTML = `Turn: <span style="color: ${currentPlayer.color}">${currentPlayer.name}</span>`;
    turnEl.style.color = 'white'; // Ensure label is white
  }

  // Scores
  const sortedPlayers = [...state.players].sort((a, b) => b.wins - a.wins);
  const scoreBoard = document.getElementById('score-board')!;
  scoreBoard.innerHTML = sortedPlayers.map(p =>
    `<div style="color: ${p.color}; font-size: 2.0rem;">${p.name}: ${p.wins}</div>`
  ).join('');
}

// Initialize Renderer globally
renderer = new Renderer(canvas);
window.addEventListener('resize', updateUILayout);

function startGame(seed: number) {
  // Clean up previous loop if exists
  if (loop) {
    loop.stop();
  }

  gameState = new GameState(LOGICAL_WIDTH, LOGICAL_HEIGHT, seed);
  // renderer is reused
  physicsEngine = new PhysicsEngine(renderer);

  // Hill parameters (for X positioning only)
  const hillWidth = 300;

  gameState.update((state) => {
    // Place castles on top of hills (X only, Y is handled by GameState)
    const p1X = hillWidth / 2;
    const p2X = LOGICAL_WIDTH - hillWidth / 2;

    const player1: Player = {
      id: 'p1',
      name: 'Red Team',
      color: '#FF0000', // Bright Red
      castlePosition: { x: p1X, y: 0 },
      cannonAngle: 45,
      health: 100,
      wins: parseInt(sessionStorage.getItem('p1_wins') || '0'),
      isMyTurn: true,
    };

    const player2: Player = {
      id: 'p2',
      name: 'Blue Team',
      color: '#0066FF', // Bright Blue
      castlePosition: { x: p2X, y: 0 },
      cannonAngle: 135,
      health: 100,
      wins: parseInt(sessionStorage.getItem('p2_wins') || '0'),
      isMyTurn: false,
    };

    gameState.addPlayer(player1);
    gameState.addPlayer(player2);

    // Start the game!
    state.gameStatus = 'playing';
  });

  loop = new GameLoop(
    (dt) => {
      gameState.update(state => {
        const wasPlaying = state.gameStatus === 'playing';
        // Wind is now updated inside PhysicsEngine's fixed step
        physicsEngine.update(state, dt, (stepDt) => gameState.updateWind(stepDt));

        if (wasPlaying && state.gameStatus === 'ending') {
          if (inputManager.canFire()) {
            console.log('Game Status Changed: playing -> ending. Disabling input.');
            inputManager.setCanFire(false);
          }
        }
      });
    },
    () => {
      const state = gameState.getState();
      renderer.render(state);
      updateHUD(state); // Update DOM HUD

      // Sync view offset and scale to input manager
      const offset = renderer.getViewOffset();
      const scale = renderer.getScale();
      inputManager.setViewOffset(offset.x, offset.y);
      inputManager.setScale(scale);
    }
  );

  loop.start();
  setupGameSubscriptions();

  // Initial UI Layout
  updateUILayout();
}

function resetGame(remoteSeed?: number) {
  // If remoteSeed is provided, it means we received a restart signal from the host.
  // We should always honor this and start immediately.
  if (remoteSeed !== undefined) {
    const overlay = document.getElementById('game-over-overlay');
    if (overlay) overlay.remove();
    startGame(remoteSeed);
    return;
  }

  // If we are in multiplayer
  if (isMultiplayer) {
    // If we are the HOST ('p1')
    if (myPlayerId === 'p1') {
      const overlay = document.getElementById('game-over-overlay');
      if (overlay) overlay.remove();

      const newSeed = Date.now();
      networkManager.sendData({ type: 'restart', seed: newSeed });
      startGame(newSeed);
    } else {
      // If we are the CLIENT ('p2')
      // Do NOT start a new game. Instead, update the overlay.
      const playAgainBtn = document.getElementById('playAgainBtn');
      if (playAgainBtn) {
        playAgainBtn.style.display = 'none'; // Hide the button
      }

      // Create or update a status message in the overlay
      let statusMsg = document.getElementById('game-over-status');
      if (!statusMsg) {
        statusMsg = document.createElement('h3');
        statusMsg.id = 'game-over-status';
        statusMsg.style.cssText = "font-size: 30px; margin-top: 20px; color: #ccc; font-family: sans-serif;";
        const overlay = document.getElementById('game-over-overlay');
        if (overlay) overlay.appendChild(statusMsg);
      }
      if (statusMsg) {
        statusMsg.innerText = "Waiting for Host...";
      }
    }
  } else {
    // Single player reset
    const overlay = document.getElementById('game-over-overlay');
    if (overlay) overlay.remove();
    startGame(Date.now());
  }
}

function updateUILayout() {
  if (!renderer) return;
  const container = document.getElementById('game-ui-container');
  if (container) {
    const scale = renderer.getScale();
    const offset = renderer.getViewOffset();

    container.style.width = `${LOGICAL_WIDTH}px`;
    container.style.height = `${LOGICAL_HEIGHT}px`;
    container.style.transform = `translate(${offset.x}px, ${offset.y}px) scale(${scale})`;
    container.style.transformOrigin = 'top left';
  }
}

import { LobbyUI } from './game/LobbyUI';

// Initialize Lobby UI
let lobbyUI: LobbyUI;

const networkManager = new NetworkManager(
  (data) => {
    if (data.type === 'fire') {
      log(`Net Fire: Ang ${data.angle} Pwr ${data.power}`);
      const otherPlayerId = myPlayerId === 'p1' ? 'p2' : 'p1';

      // Sync Wind State from the shooter
      if (data.windData) {
        gameState.setWindState(data.windData);
      }

      // Update enemy cannon angle so it looks correct when firing
      gameState.update(state => {
        const player = state.players.find(p => p.id === otherPlayerId);
        if (player) {
          player.cannonAngle = data.angle;
        }
      });

      physicsEngine.fireProjectile(gameState.getState(), data.angle, data.power, otherPlayerId, data.damageSeed);
      gameState.nextTurn();
    } else if (data.type === 'restart') {
      console.log('Received restart signal');
      resetGame(data.seed);
    }
  },
  (seed, isHost) => {
    // Multiplayer Game Start
    console.log(`Starting multiplayer game with seed: ${seed}, isHost: ${isHost}`);

    isMultiplayer = true;
    myPlayerId = isHost ? 'p1' : 'p2';

    // If we were in single player mode (default), stop it and restart with synced seed
    if (loop) loop.stop();
    lobbyUI.hide(); // Hide Lobby
    startGame(seed);
  },
  log // Pass logger
);

lobbyUI = new LobbyUI(networkManager);

const inputManager = new InputManager(
  canvas,
  (angle, power) => {
    if (!gameState) return;
    const currentPlayerId = gameState.getState().currentTurnPlayerId;

    // Local check: is it my turn?
    if (isMultiplayer && currentPlayerId !== myPlayerId) return;

    const damageSeed = Math.random();
    physicsEngine.fireProjectile(gameState.getState(), angle, power, currentPlayerId, damageSeed);
    gameState.nextTurn();

    if (isMultiplayer) {
      log(`Local Fire: Ang ${angle} Pwr ${power}`);
      const windData = gameState.getWindState();
      networkManager.sendData({ type: 'fire', angle, power, damageSeed, windData });
    }
  },
  (angle) => {
    if (!gameState) return;
    const currentPlayerId = gameState.getState().currentTurnPlayerId;
    // Only update if it's my turn
    if (isMultiplayer && currentPlayerId !== myPlayerId) return;

    gameState.update(state => {
      const player = state.players.find(p => p.id === currentPlayerId);
      if (player) {
        player.cannonAngle = angle;
      }
    });
  }
);

// UI Controls
const powerSlider = document.getElementById('powerSlider') as HTMLInputElement;
const powerValue = document.getElementById('powerValue')!;


// Multiplayer UI - Handled in HTML now
const mpLabel = document.getElementById('mp-label')!;
// const mpControls = document.getElementById('mp-controls')!;

mpLabel.addEventListener('click', () => {
  lobbyUI.show();
  lobbyUI.showMainMenu(); // Ensure main menu is shown
});

// document.getElementById('hostBtn')!.addEventListener('click', async () => {
//   isMultiplayer = true;
//   myPlayerId = 'p1';
//   document.getElementById('status')!.innerText = 'Hosting... Waiting for peer...';
//   // await networkManager.hostGame();
//   networkManager.createLobby("My Game", true);
// });

// document.getElementById('joinBtn')!.addEventListener('click', async () => {
//   isMultiplayer = true;
//   myPlayerId = 'p2';
//   document.getElementById('status')!.innerText = 'Joining... Waiting for host...';
//   // await networkManager.joinGame();
//   networkManager.listLobbies();
// });

powerSlider.addEventListener('input', (e) => {
  const val = parseInt((e.target as HTMLInputElement).value);
  powerValue.innerText = val.toString();
  inputManager.setPower(val);
});

function setupGameSubscriptions() {
  // AI Opponent
  const aiOpponent = new AIOpponent('p2', (angle, power) => {
    const damageSeed = Math.random();
    physicsEngine.fireProjectile(gameState.getState(), angle, power, 'p2', damageSeed);
    gameState.nextTurn();
  });

  // Game Over State
  let gameOverHandled = false;
  let teamStatusUpdated = false;

  gameState.subscribe(state => {
    // Update Multiplayer Status (Team Color)
    if (isMultiplayer && myPlayerId && !teamStatusUpdated) {
      const myPlayer = state.players.find(p => p.id === myPlayerId);
      if (myPlayer) {
        const statusEl = document.getElementById('status');
        if (statusEl) {
          statusEl.innerHTML = `You are the <span style="color: ${myPlayer.color}; font-weight: bold;">${myPlayer.name}</span>`;
          teamStatusUpdated = true; // Only set once to avoid flickering or overwriting
        }
      }
    }

    if (state.gameStatus === 'finished') {
      if (gameOverHandled) return;

      // Wait for all explosions to finish before showing Game Over
      if (state.explosions.length > 0) {
        return;
      }

      gameOverHandled = true;
      loop.stop();

      let winnerName = 'Unknown';

      if (state.winnerId === 'draw') {
        winnerName = 'Draw';
        // Increment wins for ALL players
        state.players.forEach(p => {
          p.wins++;
          sessionStorage.setItem(`${p.id}_wins`, p.wins.toString());
        });
      } else {
        const winner = state.players.find(p => p.id === state.winnerId);
        winnerName = winner?.name || 'Unknown';

        // Update Score
        if (winner) {
          winner.wins++;
          sessionStorage.setItem(`${winner.id}_wins`, winner.wins.toString());
        }
      }

      // Create Game Over Overlay
      const overlay = document.createElement('div');
      overlay.id = 'game-over-overlay';
      overlay.style.cssText = `
          position: absolute;
          top: 0; left: 0; width: 100%; height: 100%;
          background: rgba(0, 0, 0, 0.7);
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          color: white;
          font-family: sans-serif;
          z-index: 1000;
        `;

      overlay.innerHTML = `
          <h1 style="font-size: 60px; color: #FFD700; text-shadow: 4px 4px #000;">${state.winnerId === 'draw' ? "It's a Draw!" : "Game Over!"}</h1>
          <h2 style="font-size: 40px;">${state.winnerId === 'draw' ? "Both Teams Win!" : `Winner: ${winnerName}`}</h2>
          <h3 style="font-size: 30px;">in ${state.round} volleys</h3>
          <div style="font-size: 30px; color: #aaa; margin-bottom: 10px;">MP: ${isMultiplayer} ID: ${myPlayerId}</div>
          <button id="playAgainBtn" style="padding: 15px 30px; font-size: 30px; cursor: pointer; font-family: sans-serif;">Play Again</button>
        `;

      document.getElementById('game-ui-container')!.appendChild(overlay);

      const btn = document.getElementById('playAgainBtn')!;
      const handleReset = (e: Event) => {
        e.preventDefault();
        e.stopPropagation();
        resetGame();
      };
      btn.addEventListener('touchstart', handleReset, { passive: false });
      btn.addEventListener('click', handleReset);

      return;
    }

    // Input Handling
    inputManager.setCanFire(state.gameStatus === 'playing');

    if (isMultiplayer) {
      inputManager.setMyTurn(state.currentTurnPlayerId === myPlayerId);
      // Debug info removed


      // Update cannon position for aiming
      const myPlayer = state.players.find(p => p.id === myPlayerId);
      if (myPlayer) {
        inputManager.setCannonPosition(myPlayer.castlePosition.x, myPlayer.castlePosition.y - 70);
      }

    } else {
      const isP1Turn = state.currentTurnPlayerId === 'p1';
      inputManager.setMyTurn(isP1Turn); // Local play: P1 is human

      if (isP1Turn) {
        const p1 = state.players.find(p => p.id === 'p1');
        if (p1) {
          inputManager.setCannonPosition(p1.castlePosition.x, p1.castlePosition.y - 70);
        }
      }

      // AI Update
      if (!isMultiplayer) {
        aiOpponent.update(state);
      }
    }
  });
}

// Start single player immediately with random seed
if (!isMultiplayer) {
  startGame(Date.now());
}
